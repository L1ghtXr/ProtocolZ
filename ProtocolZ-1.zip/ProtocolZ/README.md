# ProtocolZ

**One Platform. Every Layer. Resilient by Design.**

Open-source defense platform for infrastructure you own or are authorized to protect.
Owner: L1ghtXr. Version 0.2.0 — **pre-alpha**. Not audited, not certified, not production-proven.

> ProtocolZ makes **no claim** of beating any commercial product, of "AI-powered" protection, or of any
> mitigation capacity. A small VPS cannot absorb traffic beyond its own uplink; volumetric attacks need
> upstream scrubbing, which this repo can only *request* through a generic webhook. See
> [docs/benchmarks.md](docs/benchmarks.md) and [docs/capacity.md](docs/capacity.md) for what is (and is not) measured.

## What is real today

| Component | Where | State |
|---|---|---|
| nftables firewall: validated policy, default-deny render, `nft -c` dry-run, snapshot, confirm-or-rollback, detached watchdog, reboot-persistence file, per-rule and per-source limits | `integrations/nftables` | Implemented, unit-tested. **Never run against a real kernel** (see below). Per-source limit syntax is unverified. |
| Control plane: admin auth (scrypt, lockout, TOTP MFA), RBAC, tenant isolation, asset/provider/node registry, signed policy bundles, hash-chained audit, upstream-mitigation requests, HTTP API | `control-plane` | Implemented, tested (incl. cross-tenant and tamper cases). SQLite, single instance. No built-in TLS. |
| Node agent: pulls signed policy, applies through the safe pipeline, caches, keeps enforcing during control-plane outage | `data-plane/protocolz_dp/agent.py` | Implemented, tested against a real control-plane server with a fake `nft`. |
| Web Shield: strict HTTP/1.1 reverse proxy with per-IP rate and connection limits, request validation, regex block rules, security headers, audit events | `data-plane/protocolz_dp/proxy.py` | Implemented, tested. Basic abuse control, **not a full WAF**; no TLS, no keep-alive. |
| Game Shield: Minecraft Java (handshake validation, conn/login limits, PROXY protocol) and Bedrock (RakNet framing validation, session relay, rate limits) | `data-plane/protocolz_dp/minecraft.py` | Implemented, tested with synthetic traffic only. Never tried against real clients/servers. |
| VPS Shield (read-only): exposed-port audit, SSH hardening advice, file-integrity baseline, host metrics | `data-plane/protocolz_dp/vps.py` | Implemented, tested. Never modifies the host. No intrusion-indicator or update checks yet. |
| Intelligence: explainable per-metric baselines + correlation + hysteresis | `detection` | Implemented as a library; `vps watch` feeds it host metrics. **Not wired to automatic mitigation.** Synthetic-data evaluation only. |
| Health monitoring (TCP/HTTP, hysteresis) | `data-plane/protocolz_dp/health.py` | Implemented, tested; one-shot CLI. **No continuous daemon** wired to events/control plane yet. |
| Provider adapters | `integrations/providers` | **Only** a generic HMAC-signed webhook. No vendor-specific adapters (Cloudflare, OVH, BGP/RTBH, …). |
| Dashboard | `dashboard` | Written; statically checked (CSP-safe, no HTML sinks, syntax). **Never opened in a browser.** |
| Docker dev setup, CI workflow | `docker-compose.yml`, `.github/` | Written, **untested** (no Docker/GitHub in the authoring sandbox). |
| Benchmarks | `benchmarks/` | Single-core Python microbenchmarks, measured. No comparison with other products, no kernel-level numbers. |

Not implemented: TLS termination anywhere, multi-region orchestration/failover, HA control plane, Postgres/Redis/Prometheus/OpenTelemetry
(stdlib + SQLite only, by design for now), secret-manager integration, master-key rotation, Go/Rust components (no benchmark justified them yet).

## Quick start

Python ≥ 3.10, **no third-party packages**. Applying firewall rules needs Linux, root and `nft`.

```bash
make test        # 193 tests (189 run in a plain sandbox; 4 real-kernel tests skip unless root + nft + iproute2)
make bench       # microbenchmarks, loopback only
export PYTHONPATH=integrations/nftables:common:detection:data-plane:control-plane:integrations/providers

# firewall (see docs/deployment.md before using on a real host)
python3 -m protocolz_nft validate policy.json && python3 -m protocolz_nft render policy.json
sudo python3 -m protocolz_nft dry-run policy.json
sudo python3 -m protocolz_nft apply --yes policy.json      # auto-rollback in 60 s unless `confirm` from a 2nd session

# control plane + dashboard on loopback
PROTOCOLZ_ADMIN_PASSWORD='...at least 12 chars...' python3 -m protocolz_cp create-superadmin --username admin
python3 -m protocolz_cp serve            # http://127.0.0.1:8443 (plain HTTP: put TLS in front)

# data plane
python3 -m protocolz_dp proxy   --listen-port 8080 --origin 127.0.0.1:8081 --rate 20
python3 -m protocolz_dp java    --listen-port 25565 --backend 127.0.0.1:25566 --proxy-protocol
python3 -m protocolz_dp bedrock --listen-port 19132 --backend 127.0.0.1:19133
python3 -m protocolz_dp vps audit --policy policy.json
python3 -m protocolz_dp vps watch --samples 60
python3 -m protocolz_dp.agent --cp-url https://cp.example.com --node-id n_… --persist /etc/protocolz/protocolz.nft
```

## Safety design

- `management_cidrs` is mandatory in every firewall policy; no policy can be built that omits admin access.
- Changes need explicit authorization (`--yes`, root, RBAC). VPS Shield never writes to the host except its own baseline file.
- Every firewall change: validate → `nft -c` → snapshot → atomic apply → health check → confirm-or-rollback, with a detached watchdog if your session dies.
- Policy reaches nodes only as HMAC-signed, node-bound, strictly-increasing-version bundles; forged, replayed, wrong-node and tampered-cache bundles are rejected (tested).
- Mitigation requests are refused unless the target lies inside an asset owned by the requesting tenant (tested); tenants cannot register overlapping or huge ranges.
- Secrets are never stored in the repo; provider secrets are referenced by environment-variable name, not stored in the database.
- No offensive features. The benchmark tool can only target 127.0.0.1, with fixed request counts and a time cap.

## Known limitations (the important ones)

1. **Real-kernel behaviour is unverified.** `tests/test_nft_netns.py` (two namespaces + veth, checks allow/drop/rollback and `nft -c` on the per-source syntax) is written but has *never been executed*. Run `sudo make test` on a disposable VM before trusting any firewall claim.
2. Rate limits in the firewall are per rule/address-family; per-source limits exist but their nft syntax is unverified.
3. The proxy and shields run in Python on one core: they are abuse-control layers, not high-throughput scrubbers (measured numbers in docs/benchmarks.md).
4. The audit hash chain detects edits and middle-row deletion, **not deletion of the newest rows** (anchor it externally if that matters).
5. Remotely pushed node policy is applied without a human confirmation step; stage on a canary node.
6. The detector cannot see small increases (a 1.5× spike went undetected in the synthetic test) and a sustained anomaly is slowly re-learned as baseline.
7. No TLS is terminated by any component; run the control plane on loopback behind a TLS proxy (`--trusted-proxy` for correct client IPs).

More: [architecture](docs/architecture.md) · [threat model](docs/threat-model.md) · [deployment](docs/deployment.md) · [API](docs/api.md) ·
[incident response](docs/incident-response.md) · [capacity](docs/capacity.md) · [benchmarks](docs/benchmarks.md) · [SECURITY](SECURITY.md)

## License

MIT (placeholder choice from the scaffold; the owner, L1ghtXr, should confirm the license and the copyright line).
