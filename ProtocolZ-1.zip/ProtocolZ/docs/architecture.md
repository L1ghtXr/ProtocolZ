# Architecture (v0.2.0)

```
 Dashboard (static)  ──►  Control plane (auth, RBAC, tenants, assets, providers, nodes, audit)  ── SQLite
                                  │  signed policy bundles (HMAC, node-bound, versioned) ▲ events
                                  ▼                                                       │
 Node:  agent ──► safe apply pipeline ──► nftables (kernel)         Web Shield · Java/Bedrock shields (user space)
                       ▲                                              VPS Shield (read-only) ──► metrics ──► Detector
                       └── persisted ruleset + cached bundle          Provider adapters (signed webhook) ──► upstream scrubbing
```

| Plane / part | Code | Notes |
|---|---|---|
| Control plane | `control-plane/protocolz_cp` | `service.py` holds all authorization; `server.py` is a thin stdlib HTTP layer. |
| Enforcement data plane | `integrations/nftables`, `data-plane/protocolz_dp/{proxy,minecraft}.py` | Kernel rules for L3/L4; user-space shields for HTTP and Minecraft framing. |
| Provider adapters | `integrations/providers` | Generic signed webhook only. |
| Detection & analytics | `detection/protocolz_detect`, `data-plane/protocolz_dp/vps.py` | Library + host-metric source; no auto-mitigation. |
| Monitoring | `data-plane/protocolz_dp/health.py`, JSONL event logs, audit chain | No Prometheus/OTel yet. |
| Admin dashboard | `dashboard/` | Vanilla JS, CSP-safe. |
| Tenant management | `service.py` | Tenant-scoped everything; overlap and range rules for assets. |
| Shared | `common/protocolz_common` | HMAC signing, token-bucket limiter, event log. |

## Design rules (each backed by a test unless marked)
1. **Local defense survives control-plane loss.** The kernel keeps loaded rules; the agent makes no changes on fetch failure and can re-apply its cached, verified bundle after reboot. The control plane is never in the packet path.
2. **Changes fail safe.** Validation → `nft -c` → snapshot → atomic apply → health → confirm-or-rollback (+ detached watchdog). Outages fail static.
3. **No silent changes.** Mutations need explicit authorization; VPS Shield is read-only; nothing edits `nftables.conf` for you.
4. **Authority is checked in the service layer**, not the HTTP layer, so a missing route check cannot bypass RBAC or tenant isolation.
5. **Untrusted input is parsed strictly**: policies reject unknown fields; the proxy rejects smuggling vectors; Minecraft packets are bounds-checked; the client IP is the TCP peer unless an operator names a trusted proxy.
6. **Explainable detection**: every verdict lists metric, value, baseline and score. No ML claims.
7. **Minimal dependencies**: stdlib only. Go/Rust only if a benchmark justifies it *(not yet needed — unmeasured at kernel scale)*.
8. **Local vs upstream is explicit** *(partly)*: mitigation requests go to a provider and are audited; the local code never claims to absorb volumetric floods.

## Proxy and shield behaviour (exact limits)
- Web Shield: one request per connection; `Transfer-Encoding` → 501; duplicate/non-digit `Content-Length` → 400; one `Host` required on HTTP/1.1; methods allow-listed; absolute-form/`CONNECT` refused; headers ≤ 16 KB / 100; body ≤ 1 MiB; head timeout 10 s; client-supplied `X-Forwarded-For`/`X-Real-IP`/`Forwarded` are discarded; security headers added only when the origin did not set them; no WebSocket/Upgrade; no TLS.
- Java shield: first packet must be a valid Handshake (id 0, state 1/2/3, ≤1 KiB), rejected early on a wrong first byte; legacy 0xFE pings dropped; per-IP new-connection and login limits; optional PROXY v1 header to the backend.
- Bedrock shield: only well-formed unconnected pings / open-connection-request-1 create sessions; connected-range datagrams without a session are dropped; per-IP ping and new-session limits; idle sweep; backend sees the shield's address (no PROXY protocol in Bedrock) → firewall the backend to the shield.

## Milestones
| # | Milestone | State |
|---|---|---|
| M0 | Scaffold, architecture, threat model, firewall module | done |
| M1 | Safe-apply hardening: watchdog, persistence, per-source limits | done (unit-tested); **real-kernel run pending** |
| M2 | Control plane: auth + MFA, RBAC, tenants, assets, providers, nodes, signed policy, audit, API | done |
| M3 | Web Shield, health checks, dashboard | done (dashboard never browser-tested; no health daemon) |
| M4 | Game Shield (Java + Bedrock) | done (synthetic traffic only) |
| M5 | Detection engine + benchmark harness + VPS Shield | done (synthetic evaluation; not wired to mitigation) |
| M6 | Node agent + provider adapter | agent + generic webhook done; vendor adapters, regional failover, HA **not done** |
| M7 | Run real-kernel/Docker/CI tests; browser-test dashboard; comparative benchmarks | **next** |
