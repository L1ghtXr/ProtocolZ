# Deployment

> Pre-alpha, never run on production hardware. Use a disposable VM first and keep out-of-band console access (provider VNC/rescue).

## 0. Verify on a real kernel (do this first)
```bash
sudo apt install nftables iproute2 python3     # or your distro's equivalent
sudo make test                                   # runs tests/test_nft_netns.py (4 tests, otherwise skipped)
```
If these fail, **do not use the firewall module**; open an issue with the output.

## 1. Firewall on one host
1. Write `policy.json` (always your real admin IP/CIDR in `management_cidrs`).
2. `python3 -m protocolz_nft validate|render policy.json`, review the output, then `sudo ... dry-run policy.json`.
3. In `tmux`: `sudo ... apply --yes --persist /etc/protocolz/protocolz.nft policy.json`. In a **second** SSH session: `sudo ... confirm` within 60 s, or the old rules return (also via a detached watchdog if your session dies).
4. Persistence: add `include "/etc/protocolz/protocolz.nft"` to `/etc/nftables.conf` yourself (ProtocolZ never edits it) and enable the nftables service.
5. Recovery: `... rollback --yes`, or `nft -f /var/lib/protocolz/backups/<latest>.nft`, or `nft delete table inet protocolz`.

## 2. Control plane
```bash
export PROTOCOLZ_CP_DB=/var/lib/protocolz/cp.db PROTOCOLZ_CP_KEY_FILE=/var/lib/protocolz/cp.key
PROTOCOLZ_ADMIN_PASSWORD='…' python3 -m protocolz_cp create-superadmin --username admin
python3 -m protocolz_cp serve --port 8443 --trusted-proxy 127.0.0.1     # loopback only
```
Terminate TLS in front (nginx/Caddy/HAProxy → `127.0.0.1:8443`), pass `X-Forwarded-For`, and pass `--trusted-proxy <proxy peer IP>`. To bind a non-loopback
address you must add `--behind-tls-proxy` (a statement that TLS is in front). **Back up the DB and the key file together**; see docs/capacity.md for restore caveats.
Then: create a tenant and a tenant admin (API), enable MFA (`/api/totp/*`), register assets and a node. The node's credentials are shown once.

## 3. Node agent
```bash
export PROTOCOLZ_NODE_AUTH_TOKEN=… PROTOCOLZ_NODE_SIGN_KEY=…     # from node registration
sudo -E python3 -m protocolz_dp.agent --cp-url https://cp.example.com --node-id n_… --persist /etc/protocolz/protocolz.nft
```
Run under systemd with `Restart=always`. On start it re-applies its cached bundle (works with the control plane down). Stage new policies on a canary node first.

## 4. Shields
`python3 -m protocolz_dp proxy|java|bedrock …` (see README). Bind them on the public interface, point `--origin/--backend` at a loopback or private address,
and firewall the origin/backend so only the shield can reach it (origin protection is a firewall job). Java: use `--proxy-protocol` only if the backend is configured to trust it. TLS is not terminated by the Web Shield.

## 5. VPS Shield (read-only)
`python3 -m protocolz_dp vps audit --policy policy.json` · `vps fim-init --baseline /var/lib/protocolz/fim.json /etc /usr/local/bin` · `vps fim-check --baseline …` (cron) · `vps watch`.

## Not covered
Docker deployment (`docker-compose.yml` is untested), multi-region rollout, HA, vendor mitigation adapters, upgrades/migrations (the SQLite schema has no versioned migrations yet).
