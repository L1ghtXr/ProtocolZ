# Threat Model (v0.2.0)

**Assets:** host reachability (especially admin access), firewall policy integrity, tenant data, node credentials and signing keys, provider webhook secrets,
admin sessions, the audit log. **Actors:** unauthenticated remote attacker; malicious or compromised tenant user; compromised node; network attacker between
node and control plane; local unprivileged user; careless administrator (the likeliest cause of outages).
**Trust boundaries:** operator ↔ CLI/API; node ↔ control plane; tenant ↔ tenant; ProtocolZ ↔ provider; client ↔ shields.

| Threat | Mitigation | Status |
|---|---|---|
| Admin lock-out by default-deny | Mandatory `management_cidrs`; `nft -c`; snapshot; confirm-or-rollback; detached watchdog | Implemented, tested with fakes; **real-kernel test written, never run** |
| Rule injection through policy fields | Strict schema, unknown fields rejected, name regex, int-only ports, CIDRs re-rendered from parsed objects | Implemented, tested |
| Credential stuffing / brute force | scrypt, per-IP limiter, per-account lockout, generic error, timing equalization for unknown users, TOTP with replay protection | Implemented, tested. Lockout can be used to lock a victim out (DoS) — traded for brute-force safety |
| All clients share one limiter bucket behind a proxy | `--trusted-proxy` (rightmost X-Forwarded-For) | Implemented, tested; **off by default** |
| Cross-tenant data access / claiming others' IP space | Tenant scoping in the service layer, 404 for foreign objects, overlap and prefix-length rules, mitigation only inside own assets | Implemented, tested |
| Forged / replayed / mis-targeted policy to nodes | HMAC-SHA256 bundle, node-bound, strictly increasing version, per-node derived keys; cache re-verified on restore | Implemented, tested. HMAC = shared key (a compromised node knows only its own key); asymmetric signing not implemented |
| Control-plane compromise pushes hostile policy | Policy still must pass schema + `nft -c` + health + rollback and include `management_cidrs`; audit trail | Partial: a compromised control plane **can** push a policy that blocks legitimate traffic |
| Credentials over cleartext | Agent and webhook refuse http except loopback with opt-in; CP refuses non-loopback bind without `--behind-tls-proxy` | Implemented, tested; **no TLS in the repo itself** |
| Audit tampering | Hash chain, `verify`; DB/key 0600 | Edits and middle deletions detected; **deleting the newest rows is not detected** |
| Request smuggling / header abuse / slowloris at the proxy | Strict parser, no TE, single Content-Length, timeouts, size caps, per-IP conn cap | Implemented, tested |
| Dashboard XSS | No HTML sinks, strict CSP (no inline script/style), token only in memory | Statically tested; **never run in a browser** |
| Malformed Minecraft traffic reaching the backend | Handshake/RakNet validation before relay, early rejection, rate limits | Implemented, synthetic tests only |
| Provider SSRF / secret leakage | URL policy, no redirects, secret by env-var name, never in DB/audit | Implemented, tested |
| Shell/command injection | `subprocess` argv lists, no shell | Implemented |
| Volumetric DDoS above uplink | Upstream scrubbing via provider | **Not mitigated locally; vendor adapters absent** |
| Rate-budget starvation by floods | Per-source dynamic sets (opt-in) | Implemented; **syntax unverified on real nft** |
| Detector blinding by slow ramp or baseline poisoning | Frozen deviation + slowed adaptation during anomalies | Mitigated, with documented trade-offs; small (<~1.6×) rises are invisible |
| Unauthorized host changes by VPS Shield | Read-only by construction (tested: sshd_config untouched) | Implemented |
| Offensive misuse | No packet generation; benchmark tool loopback-only, capped | Policy + code constraint |

Out of scope: kernel/hardware vulnerabilities, physical access, attacks beyond host network capacity, a compromised root account on a node.
