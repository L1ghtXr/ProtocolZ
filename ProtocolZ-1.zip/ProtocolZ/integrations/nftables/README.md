# nftables integration — module report

**Implemented:** policy validation; default-deny renderer (input hook only; per-rule and per-source limits); `nft -c` dry-run; snapshot; atomic apply;
health-check hook; confirm-or-rollback; detached watchdog; reboot-persistence file; manual rollback; JSONL events; CLI.
**Tests:** unit tests with a fake runner and a fake `nft` script (real subprocess + watchdog). `tests/test_nft_netns.py` = real-kernel tests, **written but never executed**.
**Known limitations:** syntax unverified on real nft (esp. per-source sets); input hook only (no forward/output); IPv4/IPv6 only; persistence requires you to include the file from `nftables.conf`.
**External requirements:** Linux, root, nftables, Python ≥ 3.10. **Deploy:** docs/deployment.md.
**Remaining:** run netns tests on a real host; SYN-specific rules; remote runner for the agent; forward-chain policies.
