# Changelog

## 0.2.0 — unreleased
- Control plane: scrypt passwords, lockout, TOTP MFA, RBAC, tenant isolation, asset/provider/node registry, HMAC-signed node-bound versioned policy bundles, hash-chained audit, upstream-mitigation requests (ownership-checked), HTTP API, `--trusted-proxy`.
- Node agent: signed-bundle pull, safe apply, cache + restore, outage-tolerant, event outbox.
- Web Shield reverse proxy, Minecraft Java and Bedrock shields, health checks, read-only VPS Shield, explainable detector, generic signed-webhook provider.
- nftables: detached rollback watchdog, reboot-persistence file, per-source dynamic-set limits (syntax unverified), real-kernel netns tests (written, never run).
- Dashboard (static, CSP-safe), benchmark harness with measured results, docs (architecture, threat model, API, deployment, incident response, capacity).
- Owner/copyright holder changed to L1ghtXr.
- Fixed while testing: integer "CIDR" accepted by validation; detector baseline poisoning by sustained floods; Minecraft shield held connections for non-handshake bytes; mitigation target not normalized before being sent; flaky agent backoff test.

## 0.1.0
- Scaffold, architecture and threat-model documents; nftables dry-run/rollback module.
